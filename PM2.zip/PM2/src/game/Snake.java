/**
 * Snake.java
 * @author Ferdinand Trendelenburg.
 * @author Thorben Schomacker.
 */
package game;

/**
 * @author Thorben
 *
 */
public class Snake {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Movement();
		new Gui();
		new Var();

	}

}
