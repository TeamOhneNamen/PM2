# Author:: Ferdinand Trendelenburg
# Author:: Thorben Schomacker

require_relative './pet.rb'
require_relative './human.rb'

class Cat < Pet
  def initialize(name, day, month, year, lifes = 9)
    create(name, day, month, year, lifes)
    @staff = []
  end
  
  def kill(other)
    other.die(self)
  end
  
  def add_staff(human)
    @staff << human
  end
  
  def die(reason)
    raise ArgumentError, "#{@name}, you can't kill yourself" if reason.eql? self
    raise ArgumentError, "Only Cats can kill Cats" unless reason.is_a?(Cat)
    raise ArgumentError, "#{@name} already died" if @lifes > 0 
    @lifes -= 1
  end
  
  def demand(action, human)
    raise ArgumentError, "you aren't allowed to serve #{@name}" unless @staff.include?(human)
    raise ArgumentError, 'choose between pet or feed' unless action == ('pet' ||'feed')
    pet if action == 'pet'
    feed if action == 'feed'
  end 
  
  def to_s_extra
    counter = 0
    @personal = ''
    @staff.length.times{
    @personal += ' ' + @staff[counter].to_s
    counter += 1}
    "his/her staff:#{@personal}"
  end
end

garfield = Cat.new('Garfield', 12, 12, 2000, lifes = 9)
john = Human.new('john')
garfield.add_staff(john)
gato = Human.new('gato')
garfield.add_staff(gato)
garfield.demand('pet', john)
garfield.kill(garfield)
puts garfield