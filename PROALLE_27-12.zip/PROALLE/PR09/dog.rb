# Author:: Ferdinand Trendelenburg
# Author:: Thorben Schomacker

require_relative './pet.rb'
require_relative './human.rb'

class Dog < Pet
  def initialize(name, day, month, year, owner, lifes = 9)
    create(name, day, month, year, lifes)
    @owner = owner
  end

  def to_s_extra
    "his/her owner: #{@owner.to_s}"
  end
end