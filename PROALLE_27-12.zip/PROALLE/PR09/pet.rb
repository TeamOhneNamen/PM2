# Author:: Ferdinand Trendelenburg
# Author:: Thorben Schomacker

require 'date'
class Pet
  
  def create(name, day, month, year, lifes = 1)
    @name = name
    @birth = Date.new(year,month,day)
    @lifes = lifes
    @petted = 0
    @fed = 0
  end
  
  def to_s
    "#{@name}, is a #{self.class}, was born #{@birth}, has still #{@lifes} lifes to live" +
    ", was petted #{@petted} times, was fed #{@fed} times" + ', ' +
    to_s_extra.to_s
  end
  
  def to_s_extra
    "his/her owner: #{@owner}"
  end
  
  def pet
    @petted += 1
  end
  
  def feed
    @fed += 1
  end
end