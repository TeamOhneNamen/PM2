class Stack
  def initialize
   @arr = []
  end
  def push(value)
    if value == nil
      raise ArgumentError, 'not nil'
    end
    @arr.push(value)
    self
  end
  def peek
    raise EmptyStackError if empty?
    @arr.last
  end
  def pop
    raise EmptyStackError if empty?
    @arr.pop
    nil
  end
  def empty?
    @arr.empty?
  end
  def to_s
    @arr.to_s
  end
end