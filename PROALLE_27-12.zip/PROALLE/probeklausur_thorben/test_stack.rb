# Testfälle für Stack
# Author:: Bernd Kahlbrandt
require 'test/unit'

require_relative '3_stack.rb'
require_relative 'emptystackerror.rb'

class TestStack < Test::Unit::TestCase
  def setup
    @stack_num = Stack.new
    @stack_string = Stack.new
    @stack_mix = Stack.new
  end

  def test_initialize
    @stack_num = Stack.new()
    assert(@stack_num.empty?())
  end

  def test_push
    assert_raise(ArgumentError,"Sie haben versucht nil einzufügen!") {@stack_num.push(nil)}
    refute(@stack_num.push(1).empty?)
  end

  def test_peek
    assert_raise(EmptyStackError){@stack_mix.peek}
    @stack_num.push(1)
    assert_equal(1,@stack_num.peek)
    @stack_mix.push(42).push("08/15")
    assert_equal("08/15",@stack_mix.peek)
  end
  def test_pop
    assert_raise(EmptyStackError){@stack_mix.peek}
    @stack_num.push(1)
    @stack_num.pop
    assert(@stack_num.empty?)
    @stack_mix.push(42).push("08/15")
    refute(@stack_mix.empty?)
  end

  def test_empty
    assert(Stack.new().empty?)
    refute(@stack_num.push(1).empty?)
  end
end