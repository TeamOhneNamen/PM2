class UngeradeZahl
  include Comparable
  
  def initialize(number)
    @number = number
    if @number.is_a?(Integer) && @number.odd?
    else
      raise ArgumentError, 'has to be an odd Integer'
    end
  end

  def number
    @number
  end
  def to_s
    @number.to_s
  end
  
  def succ()
    UngeradeZahl.new(@number + 2)
  end
  
  def count
    @number.count
  end
  
  def <=>(other)
    if other.is_a?(UngeradeZahl)
      @number<=>other.number
    elsif other.is_a?(Integer)
      @number<=>other
    end
  end
end
a = UngeradeZahl.new(1)