class Summe
  def initialize(input)
    check(input)
    eins(input)
    zwei(input)
  end
  def check(input)
    raise TypeError, "Should be ENUMERABLE" unless input.is_a?(Enumerable)
    raise TypeError, "Should be NUMERIC" unless input.all? {|a| a.is_a?(Numeric)}
  end
  
  def eins(input)
    sum = 0
    counter = 0
    input.length.times{sum += input[counter] 
    counter += 1}
    puts sum
  end
  def zwei(input)
    sum = 0
    input.each{|a| sum += a}
    puts sum 
  end
end
a = Summe.new([1, 2, 3])