class Test
  def test
    asdf = ""
    asdf.freeze
    p asdf.frozen?
    asdf2 = asdf.dup
    puts asdf2.frozen?
  end
  def send_mail(source)
    Mailer.deliver(to: 'thorben.schomacker@gmail.com', from: 'angela.merkel@bundestag.de', subject: 'Important message', body: source.text)
  end
end
t = Test.new()
t.send_mail('string')