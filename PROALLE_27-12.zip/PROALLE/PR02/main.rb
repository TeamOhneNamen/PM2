# Dies ist die main, sie ist die Datei die ge�ffnet wird und das Programm durch die dareien Navigiert!

# Author:: Ferdinand Trendelenburg
# Author:: Thorben Schomacker

require_relative "./interactiv.rb"

int = Interactiv.new
int.interaction_begruessung