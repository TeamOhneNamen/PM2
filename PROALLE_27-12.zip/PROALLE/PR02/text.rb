Thorben
Ferdinand

Die Eingabe funktioniert über die Konsole. Dort gibt der Anwender eine Zahl (sowohl Integer als float) mit Einheiten Kürzel ein. Dann wird das Einheitenkürzel
von der Zahl getrennt. Diese Zahl wird dann zu nächst in p und dann wenn gewünscht noch in eine andere Einheit umgerechnet. Die Methode für Tabelle multipliert
den Wert chronologisch mit den Zahlen 1-10, zu diesen Werten gibt er dann die entsprechende Konvertierung in den drei Basiseinheiten der Systeme (m, ft, p).
Ob eine Tabelle gewünscht ist oder nicht, kann über die Konsole durch j (Ja) oder n (Nein).
  
Doch es gab Dinge, die uns bei dieser Aufgabe schwer gefallen sind, zum Beispiel war das Rechnen mit den Integer Werten nicht möglich, so mussten wir sie in float Zahlen umschreiben.
  auch sie Aufgabenstellung für Aufgabe 5 war uns nicht zu 100% verständlich und ein wenig schwammig formuliert.
