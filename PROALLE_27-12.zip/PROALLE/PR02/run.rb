# Author:: Thorben Schomacker

#require 'main'
require 'interactiv'
a = interactiv.new