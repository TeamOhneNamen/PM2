require_relative 'teil.rb'

name = "A"
gewicht = 10
kinder = []
franz = Teil.new(name, gewicht, [nil])
@bobby = Teil.new(name, gewicht, [franz])
@berta = Teil.new(name, gewicht, [franz])
kinder = [@bobby, @berta]
#kinder = [1, 2]
a = Teil.new(name, gewicht, kinder)
puts a
puts a == a
#puts a.get_children
#puts a.bill_of_materials
puts a.bill_of_materials == [@bobby, @berta]
puts a.get_children == [@bobby, @berta]
puts a.bill_of_materials[0] == @bobby
puts a.get_children[0] == @bobby
puts "array: #{a.get_children.is_a?(Array)}"
#p a.deep_to_s