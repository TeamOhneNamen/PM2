# Author:: Ferdinand Trendelenburg
# Author:: Thorben Schomacker

class Deque
  def initialize(array = [])
    raise ArgumentError, "It has be an ARRAY, you gave a #{array.class}" unless array.is_a?(Array)
    @daten = array
  end

  def enqueue(element)
    # adds element to the deque
    # return self for allow chaining
    @daten << element
    return self
  end

  def dequeue
    # deletes first element of @daten
    # return self for allow chaining
    @daten.delete_at(0)
    return self
  end

  alias_method :push, :enqueue

  def pop
    # deletes last element of @daten
    # return self for allow chaining
    @daten.pop
    return self
  end
  
  def to_s(position = nil)
    # without given position return content of the deque
    # with given position return content at the given position
    # uses clone for securing the content
    return @daten.clone.to_s if position == nil
    return @daten.clone[position] unless position == nil
  end
end
